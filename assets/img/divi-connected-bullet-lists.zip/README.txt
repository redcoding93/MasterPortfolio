A Pen created at CodePen.io. You can find this one at https://codepen.io/houteng/pen/GvopZx.

 This set of codes styles the Elegant Themes' Divi Wordpress theme numbered list. This was adapted from the Elegant Themes' blog post and edited to make its application easier.